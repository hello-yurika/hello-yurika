## Setup Instructions

### Step 1: Start Docker
Open your terminal and run the following command:
```sh
cd prototype-server/CloudCabinetWebApi
docker compose up -d
```

### Step 2: Run Migrations
To update the database, execute:
```sh
dotnet ef database update --context ApplicationDbContext
```
If necessary, install the required tools:
1. Download .NET (from homebrew)
    ```sh
    brew tap isen-ng/dotnet-sdk-versions
    brew install --cask dotnet-sdk6
    brew install --cask dotnet-sdk8
    dotnet --list-sdks
    ```

2. Install the EF tool:
    ```sh
    dotnet tool install --global dotnet-ef
    ```

### Step 3: Insert SQL Data
1. Run the SQL file named RUN-THIS-SQL.sql
2. Run the SQL file named SeedSQL/MstLogDisplay.sql

### Step 4: Run the Solution
Execute the solution using:
```sh
dotnet run
```

### Step 5: Run the Front-End
Go to folder:
```
cloud-cabinet/public/pdfjs
```
and run 
```sh
npm install
```

If something goes wrong, you can use the pdfjs copy that is in the `ss-cloud-cabinet-front-pdfjs` repository.
You only need to copy the node_modules folder.

Go to folder:
```
cloud-cabinet/
```
and run 
```sh
npm install
npm start
```

### Step 6: Login
Now you should be able to access the system using the following login credentials:

#### User 1: 管理者（admin privilegies）

- **Tenant Code**: `it0001`
- **Email**: `admin@mail.com`
- **Password**: `Test1234`

```json
{
  "tenantCode": "it0001",
  "email": "admin@mail.com",
  "password": "Test1234"
}
```

#### User 2: 寺田倉庫（super admin privilegies）

- **Tenant Code**: `it0001`
- **Email**: `terada@mail.com`
- **Password**: `Test1234`

```json
{
  "tenantCode": "it0001",
  "email": "terada@mail.com",
  "password": "Test1234"
}
```

## Swagger Access (Not necessary)

You can access Swagger at the following URL:

[https://localhost:7014/swagger/index.html](https://localhost:7014/swagger/index.html)

### Register Users via Swagger

1. **Navigate to `api/User/registerTest`**.
2. Register the following users:

#### User 1: 管理者

```json
{
  "userName": "管理者",
  "email": "admin@mail.com",
  "password": "Test1234",
  "icon": null,
  "userAuthenticationType": 1,
  "userGroupId": 255
}
```

#### User 2: 寺田倉庫

```json
{
  "userName": "寺田倉庫",
  "email": "terada@mail.com",
  "password": "Test1234",
  "icon": null,
  "userAuthenticationType": 1,
  "userGroupId": 255
}
```

#### Login

Use the following credentials to login:

- **Tenant Code**: `test`
- **Email**: `admin@mail.com`
- **Password**: `Test1234`

```json
{
  "tenantCode": "test",
  "email": "admin@mail.com",
  "password": "Test1234"
}
```

## MySQL Configuration

### Database Connection Details

- **Host**: `localhost`
- **Port**: `3306`
- **Database**: `cloudcabinet`
- **User**: `root`
- **Password**: `root`

### Modify `AspNetUser` Table

1. Set the `user_type` of the admin user to `2`.
2. Set `password_update` to `1`.
 